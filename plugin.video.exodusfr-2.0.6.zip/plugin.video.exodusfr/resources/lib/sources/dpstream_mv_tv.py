# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urlparse,time,datetime,unicodedata,sys,pkgutil

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import nombredeliens


class source:
    def __init__(self):
        print '= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = '
        print 'INIT'
        self.domains = ['www.dpstream.net']
        self.base_link = 'http://www.dpstream.net/films-recherche'
        self.search_link = '%s'


    def movie(self, imdb, title, year):
        print 'MOVIE'
        try:
            title = 'http://www.imdb.com/title/%s' % imdb

            titleFR = client.request(title, headers={'Accept-Language':'fr-FR'})
            titleFR = client.parseDOM(titleFR,'title')[0]
            titleFR = re.sub('(?:\(|\s)\d{4}.+', '', titleFR).strip()

            titleCA = client.request(title, headers={'Accept-Language':'fr-CA'})
            titleCA = client.parseDOM(titleCA,'title')[0]
            titleCA = re.sub('(?:\(|\s)\d{4}.+', '', titleCA).strip()

            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        print 'TVSHOW'
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        print 'EPISODE'
        try:
            if url == None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        print 'SOURCES'
        try:
            sources = []
            queryList = []
            cleaned_result = []

            titleFRsplit = None
            titleCAsplit = None

            if url == None: return sources

            dt = int(datetime.datetime.now().strftime('%Y%m%d'))
            mt = {'jan':'1', 'feb':'2', 'mar':'3', 'apr':'4', 'may':'5', 'jun':'6', 'jul':'7', 'aug':'8', 'sep':'9', 'oct':'10', 'nov':'11', 'dec':'12'}

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = 'http://www.imdb.com/title/%s' % data['imdb']
            print 'title = %s' % title

            request = client.request(title, headers={'Accept-Language':'fr-FR'})
            self.titleFR = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleFR = re.sub('(?:\(|\s)\d{4}.+', '', self.titleFR).strip()
            print 'titleFR 0 = %s' % self.titleFR

            request = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()
            print 'titleCA 0 = %s' % self.titleCA


            if 'tvshowtitle' in data :
                print ''
            else:
                try:
                    dataYearFR = re.compile('Release Date:</h4> (.+?) \(France\)').findall(request)[0]
                    dataYearFR = dataYearFR[-4:]
                except:
                    try:
                        dataYearFR = re.compile('Release Date:</h4> (.+?) \(USA\)').findall(request)[0]
                        dataYearFR = dataYearFR[-4:]
                    except:
                        dataYearFR = re.compile('<title>(.+?) \- IMDb</title>').findall(request)[0]
                        dataYearFR = re.compile('\((.+?)\)').findall(dataYearFR)[0]

            if self.titleFR[-1:] == '.':
                self.titleFR = self.titleFR[:-1]

            try:
                self.titleFR = re.sub('\&amp\;', '', self.titleFR).strip()
            except:
                pass

            result = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result)[0].strip()
            #self.titleCA = client.parseDOM(result,'title')[0]
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()

            if self.titleCA[-1:] == '.':
                self.titleCA = self.titleCA[:-1]

            try:
                self.titleCA = re.sub('\&amp\;', '', self.titleCA).strip()
            except:
                pass

            if 'tvshowtitle' in data :
                self.titleCA = re.sub('\(TV Series', '', self.titleCA).strip()
                self.titleFR = re.sub('\(TV Series', '', self.titleFR).strip()

            try:
                if ' - ' in self.titleFR or ' - ' in self.titleCA:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
                    queryList.append(titleFRsplit[0] + ' ' + titleCAsplit[1])
                    queryList.append(titleCAsplit[0] + ' ' + titleFRsplit[1])

                else:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
            except:
                pass

            queryList = sorted(set(queryList))

            try:
                for i in queryList:

                    query = i

                    try:
                        query = re.sub('(:)', ' :', query)

                        if ':' in query and '-' in query :
                            test = re.split('(:| - )', query)
                            #test2 = [x for x in test if x != ':']
                            #test2 = [x for x in test2 if x != ' - ']

                            lookFor1 = test[0]
                            lookFor = test[2]
                            lookFor3 = lookFor1.strip() + '-' + lookFor.strip()

                        elif ':' in query :
                            test = re.split('(:)', query)
                            #test2 = [x for x in test if x != ':']

                            lookFor1 = test[0]
                            lookFor = test[2]
                        else:
                            lookFor = query

                        if 'tvshowtitle' in data :
                            lookFor = re.sub('(\s\(TV Series|\s\(TV Mini-Series)', '', lookFor).strip()
                            #lookFor = re.sub('(\.)', '', lookFor).strip()

                    except:
                        pass

                    if 'tvshowtitle' in data :
                        typeMovies = 'tvshows'
                        typeQuery = 'field'
                    else:
                        typeMovies = 'movies'
                        typeQuery = 'q'

                    if 'tvshowtitle' in data :
                        lookFor = re.sub('(\s)', '%20', lookFor)
                        query = self.search_link % (lookFor)
                        lookFor = query
                    else:
                        query = self.search_link % (query)

                    lookFor = re.sub('\\\'', ' ', lookFor)

                    if 'tvshowtitle' in data :
                        tempSearch = 'http://www.dpstream.net/series-recherche?q=%s' % lookFor
                    else:
                        tempSearch = 'http://www.dpstream.net/films-recherche?q=%s' % lookFor
                        tempSearch = re.sub(' ', '+', tempSearch)

                    try:
                        result = client.request(tempSearch)
                    except:
                        pass

                    if 'tvshowtitle' in data :
                        print ''
                    else:
                        theTitle = re.compile('<h3 class=\"resultTitle(.+?)</h3>', re.MULTILINE|re.DOTALL).findall(result)[0]

                        try:
                            theTitle = re.compile('.html\">(.+?)</a>', re.MULTILINE|re.DOTALL).findall(theTitle)[0]
                        except:
                            pass

                        if lookFor in theTitle:
                            print ''
                        else:
                            continue

                    cleaned_result = []

                    try:
                        if result == None:
                            pass
                        else:
                            if 'tvshowtitle' in data :
                                cleaned_result = re.compile('<a href=\"/serie\-(.+?)\"').findall(result)
                            else:
                                cleaned_result = re.compile('<a href=\"/film\-(.+?)\"').findall(result)
                    except:
                        pass

                    if cleaned_result == [] :
                        continue

                    cleaned_result = sorted(set(cleaned_result))

                    langue = ''

                    for resultUrl in cleaned_result:

                        if 'tvshowtitle' in data :
                            resultUrl2 = 'http://www.dpstream.net/serie-' + resultUrl
                        else:
                            resultUrl2 = 'http://www.dpstream.net/film-' + resultUrl

                        if 'tvshowtitle' in data :

                            if int(data['season']) < 10:
                                laSaison = 'S0%s' % data['season']
                            else:
                                laSaison = 'S%s' % data['season']

                            if int(data['episode']) < 10:
                                lEpisode = 'E0%s' % data['episode']
                            else:
                                lEpisode = 'E%s' % data['episode']

                            if int(data['episode']) + 1 < 10:
                                tempEpisode = int(data['episode']) + 1
                                lEpisode2 = 'E0%d' % tempEpisode
                            else:
                                tempEpisode = int(data['episode']) + 1
                                lEpisode2 = 'E%d' % tempEpisode

                            laSaisonEpisode = '%s%s' % (laSaison, lEpisode)
                            laSaisonEpisode2 = '%s%s' % (laSaison, lEpisode2)

                            theChunk0 = 'http://www.dpstream.net/serie-' + re.sub('.html', '', resultUrl) + '/saison-%s/episode-%s.html' % (data['season'], data['episode'])
                            resultUrl2z = client.request(theChunk0)

                            theChunk2 = re.compile('id=\"show_more_result\">(.+?)class=\'prev_episode\'', re.MULTILINE|re.DOTALL).findall(resultUrl2z)[0]
                            theChunk = re.compile('&nbsp;(.+?)<tr id=\"', re.MULTILINE|re.DOTALL).findall(theChunk2)
                        else:
                            resultUrl2z = client.request(resultUrl2)

                            try:
                                theAnnee = re.compile('px\">Année</b>\s*:\s*(.+?)\s*</p>', re.MULTILINE|re.DOTALL).findall(resultUrl2z)[0]
                            except:
                                theAnnee = '1900'

                            if int(theAnnee) == 1900:
                                print ''
                            else:
                                if int(theAnnee) == int(data['year']):
                                    print ''
                                else:
                                    continue

                            theChunk0 = re.compile('<tbody id=\"show_more_result\">(.+?)<div class=\"episodeItemFooter\">', re.MULTILINE|re.DOTALL).findall(resultUrl2z)[0]
                            theChunk = re.compile('&nbsp;(.+?)<tr id=\"', re.MULTILINE|re.DOTALL).findall(theChunk0)

                            try:
                                langue0 =  re.compile('Langue</h3>(.+?)<div class=\"clearfix\"></div>', re.MULTILINE|re.DOTALL).findall(resultUrl2z)[0]
                                langue1 = re.compile('\)\">(.+?)</a>', re.MULTILINE|re.DOTALL).findall(langue0)

                                for langue3 in langue1:
                                    langue = langue + langue3 + '|'
                                langue = langue[:-1]

                            except:
                                langue = ''

                        result4 = []
                        language = ''
                        quality = 'SD'


                        if quality == 'All':
                            quality = 'SD'

                        result4 = theChunk

                        for i in result4:

                            if 'tvshowtitle' in data :
                                print''
                            else:
                                if theAnnee in dataYearFR:
                                    print''
                                else:
                                    if theAnnee == '1900':
                                        print ''
                                    else:
                                        continue

                            theChunk2 = re.compile('td data-title=\"\">(.+?)</td>').findall(i)

                            quality2nd = None

                            try:
                                quality2nd = theChunk2[1]
                                quality2nd = re.sub('(<B>|</B>|<b>|</b>)', '', quality2nd)
                            except:
                                quality2nd = 'SD'


                            theHost =  ''

                            try:
                                language = theChunk2[0]
                            except:
                                language = ''


                            if 'tvshowtitle' in data :
                                if 'toroadvertisingmedia.com' in theChunk2[3]:
                                    continue
                            else:
                                if 'toroadvertisingmedia.com' in theChunk2[4]:
                                    continue

                            if 'tvshowtitle' in data :
                                if 'teramixer.com' in theChunk2[3]:
                                    continue
                            else:
                                if 'teramixer.com' in theChunk2[4]:
                                    continue

                            if 'tvshowtitle' in data :
                                if 'xmediaserve.com' in theChunk2[3]:
                                    continue
                            else:
                                if 'xmediaserve.com' in theChunk2[4]:
                                    continue

                            try:
                                if 'tvshowtitle' in data :
                                    theUrl =  re.compile('<a href=\"http://(.+?)\"', re.MULTILINE|re.DOTALL).findall(theChunk2[3])[0]
                                else:
                                    theUrl =  re.compile('<a href=\"http://(.+?)\"', re.MULTILINE|re.DOTALL).findall(theChunk2[4])[0]

                                host = re.compile('^(.+?)/').findall(theUrl)[0]
                                url = 'http://' + theUrl
                            except:
                                if 'tvshowtitle' in data :
                                    theUrl =  re.compile('<a href=\"https://(.+?)\"', re.MULTILINE|re.DOTALL).findall(theChunk2[3])[0]
                                else:
                                    theUrl =  re.compile('<a href=\"https://(.+?)\"', re.MULTILINE|re.DOTALL).findall(theChunk2[4])[0]
                                    
                                host = re.compile('(.+?)/').findall(theUrl)[0]
                                url = 'https://' + theUrl

                            url = url.encode('utf-8')

                            nombredeliens.var1 = nombredeliens.var1 + 1

                            if 'www.' in host :
                                host = host.replace('www.', '')

                            size = '%.2f GB' % (0)

                            if '0.00 GB' in size:
                                size = ''
                            else:
                                sizel = size + ' | '

                            RDbool = False

                            host = host.encode('utf-8')

                            prefaudio = 4
                            prefaudio = int(control.setting('pref.audio'))

                            if prefaudio == 0 and language == 'VF':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Dpstream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 1 and language == 'VFQ':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Dpstream', 'info': size + quality2ndd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 2 and language == 'VO':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Dpstream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 3 and language == 'VOSTFR':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Dpstream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 4 :
                                sources.append({'source': host, 'quality': quality, 'provider': 'Dpstream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                print  exc_type, exc_tb.tb_lineno

            return sources
        except:
            return sources


    def resolve(self, url):
        print 'RESOLVE'
        return url
