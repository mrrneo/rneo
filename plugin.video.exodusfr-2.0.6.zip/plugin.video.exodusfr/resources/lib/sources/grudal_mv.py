# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse,time,datetime,unicodedata,sys,pkgutil,base64

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import pyaes
from resources.lib.modules import nombredeliens

class source:

    def __init__(self):
        self.base_link = 'http://www.grudal.com'
        self.search_link = 'http://www.grudal.com/'

    def movie(self, imdb, title, year):
        print 'MOVIE'
        try:
            title = 'http://www.imdb.com/title/%s' % imdb

            titleFR = client.request(title, headers={'Accept-Language':'fr-FR'})
            titleFR = client.parseDOM(titleFR,'title')[0]
            titleFR = re.sub('(?:\(|\s)\d{4}.+', '', titleFR).strip()
            #titleFR = ''.join((c for c in unicodedata.normalize('NFD', titleFR) if unicodedata.category(c) != 'Mn'))

            titleCA = client.request(title, headers={'Accept-Language':'fr-CA'})
            titleCA = client.parseDOM(titleCA,'title')[0]
            titleCA = re.sub('(?:\(|\s)\d{4}.+', '', titleCA).strip()
            #titleCA = ''.join((c for c in unicodedata.normalize('NFD', titleCA) if unicodedata.category(c) != 'Mn'))

            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        print 'SOURCES'
        try:
            sources = []
            queryList = []
            cleaned_result = []

            titleFRsplit = None
            titleCAsplit = None

            if url == None: return sources

            #if debrid.status() == False: raise Exception()

            dt = int(datetime.datetime.now().strftime('%Y%m%d'))
            mt = {'jan':'1', 'feb':'2', 'mar':'3', 'apr':'4', 'may':'5', 'jun':'6', 'jul':'7', 'aug':'8', 'sep':'9', 'oct':'10', 'nov':'11', 'dec':'12'}

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = 'http://www.imdb.com/title/%s' % data['imdb']
            print 'title = %s' % title

            request = client.request(title, headers={'Accept-Language':'fr-FR'})
            self.titleFR = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleFR = re.sub('(?:\(|\s)\d{4}.+', '', self.titleFR).strip()
            print 'titleFR 0 = %s' % self.titleFR

            request = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()
            print 'titleCA 0 = %s' % self.titleCA

            if 'tvshowtitle' in data :
                print ''
            else:
                try:
                    dataYearFR = re.compile('Release Date:</h4> (.+?) \(France\)').findall(request)[0]
                    dataYearFR = dataYearFR[-4:]
                except:
                    try:
                        dataYearFR = re.compile('Release Date:</h4> (.+?) \(USA\)').findall(request)[0]
                        dataYearFR = dataYearFR[-4:]
                    except:
                        dataYearFR = re.compile('<title>(.+?) \- IMDb</title>').findall(request)[0]
                        dataYearFR = re.compile('\((.+?)\)').findall(dataYearFR)[0]

            if self.titleFR[-1:] == '.':
                self.titleFR = self.titleFR[:-1]

            try:
                self.titleFR = re.sub('\&amp\;', '', self.titleFR).strip()
            except:
                pass

            result = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result)[0].strip()
            #self.titleCA = client.parseDOM(result,'title')[0]
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()

            if self.titleCA[-1:] == '.':
                self.titleCA = self.titleCA[:-1]

            try:
                self.titleCA = re.sub('\&amp\;', '', self.titleCA).strip()
            except:
                pass

            if 'tvshowtitle' in data :
                self.titleCA = re.sub('\(TV Series', '', self.titleCA).strip()
                self.titleFR = re.sub('\(TV Series', '', self.titleFR).strip()

            try:
                if '-' in self.titleFR or '-' in self.titleCA or ':' in self.titleFR or ':' in self.titleCA:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)

                    test = re.split('(:|-)', self.titleFR)
                    queryList.append(test[0])
                    queryList.append(test[2])

                    test = re.split('(:|-)', self.titleCA)
                    queryList.append(test[0])
                    queryList.append(test[2])

                else:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
            except:
                pass

            try:
                queryList = sorted(set(queryList))

                for i in queryList:

                    query = i

                    lookFor = None

                    try:
                        if 'tvshowtitle' in data :
                            lookFor = re.sub('(\s\(TV Series)', '', lookFor).strip()
                            lookFor = re.sub('(\.)', '', lookFor).strip()
                    except:
                        pass

                    url = 'http://www.grudal.com/'
                    cookie = client.request(url, output='cookie')

                    result = client.request(url)
                    url00 = re.compile('window.location.href=\"(.+?)\"').findall(result)[0]

                    url0 = 'http://www.grudal.com/%s/index.php'% url00
                    query = re.sub('(\-|:)', '', query)
                    query2 = query
                    query = re.sub(' ', '+', query)
                    post ='searchword=%s&option=com_search&view=search&Itemid=9' % query[:20]

                    result0 = client.request(url0, post=post)

                    try:
                        theTitle = re.compile('<a  href=\"/' + url00 + '/index.php\?option=com_content\&amp\;view=article(.+?)</i></font>', re.MULTILINE|re.DOTALL).findall(result0)[0]
                    except:
                        continue

                    theTitle = re.compile('>(.+?)\)', re.MULTILINE|re.DOTALL).findall(theTitle)[0].strip().lower()

                    theYear = re.compile('\((.+?)$', re.MULTILINE|re.DOTALL).findall(theTitle)[0].strip()
                    theTitle = re.sub('(\-|:)', '', theTitle)

                    theYear = dataYearFR

                    if 'tvshowtitle' in data :
                        print''
                    else:
                        if int(theYear) == int(dataYearFR):
                            print''
                        else:
                            continue

                    result1 = re.compile('<fieldset>(.+?)</i></font>', re.MULTILINE|re.DOTALL).findall(result0)[0]
                    result1a = re.compile('href=\"(.+?)\"\s*>', re.MULTILINE|re.DOTALL).findall(result1)

                    print result1a

                    if query2.lower() in theTitle:
                        print ''
                    else:
                        continue

                    result4 = []
                    result4b = []

                    for tempUrl in result1a:

                        if url00 in tempUrl:
  
                            result3 = client.request('http://www.grudal.com' + tempUrl)

                            try:
                                url5 = re.compile('/grudal3/player.php\?id=(.+?)=', re.MULTILINE|re.DOTALL).findall(result3)[0]
                                url5 = 'http://www.grudal.com/grudal3/player.php?id=' + url5 + '='
                            except:
                                url5 = re.compile('/grudal/player.php\?id=(.+?)=', re.MULTILINE|re.DOTALL).findall(result3)[0]
                                url5 = 'http://www.grudal.com/grudal/player.php?id=' + url5 + '='

                            result5 = client.request(url5)
                            result6 = re.compile('{\"file\":\"(.+?)\}', re.MULTILINE|re.DOTALL).findall(result5)

                            for iiii in result6:

                                q = re.compile('\"label\":\"(.+?)\"', re.MULTILINE|re.DOTALL).findall(iiii)[0]
                                result6b = client.request(iiii)

                                result7 = re.compile('b.php\?link=(.+?)\"', re.MULTILINE|re.DOTALL).findall(iiii)[0]
                                result8 = 'http://grudal.com/grudal/b.php?link=' + result7

                                referer = url5
                                url = result8
                                u = client.request(url, output='geturl', referer=referer)

                                result4.append(u)
                                result4b.append(q)

                index = 0

                for i in result4:

                    quality = 'SD'
                    quality2nd = result4b[index]
                    language = 'VF'

                    index = index + 1

                    url = i

                    url = url.encode('utf-8')

                    nombredeliens.var1 = nombredeliens.var1 + 1

                    size = '%.2f GB' % (0)

                    RDbool = False

                    host = 'Gvideo'

                    prefaudio = 4
                    prefaudio = int(control.setting('pref.audio'))

                    if prefaudio == 0 and language == 'VF':
                        sources.append({'source': host, 'quality': quality, 'provider': 'Grudal', 'info': size + '|' + quality2nd + '|' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                    elif prefaudio == 1 and language == 'VFQ':
                        sources.append({'source': host, 'quality': quality, 'provider': 'Grudal', 'info': size + '|' + quality2nd + '|' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                    elif prefaudio == 2 and language == 'VO':
                        sources.append({'source': host, 'quality': quality, 'provider': 'Grudal', 'info': size + '|' + quality2nd + '|' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                    elif prefaudio == 3 and language == 'VOSTFR':
                        sources.append({'source': host, 'quality': quality, 'provider': 'Grudal', 'info': size + '|' + quality2nd + '|' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                    elif prefaudio == 4 :
                        sources.append({'source': host, 'quality': quality, 'provider': 'Grudal', 'info': size + '|' + quality2nd + '|' + language, 'url': url, 'direct': False, 'debridonly': RDbool})

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                print  exc_type, exc_tb.tb_lineno

            return sources
        except:
            return sources


    def resolve(self, url):
        print 'RESOLVE'
        return url