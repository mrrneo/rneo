# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urlparse,time,datetime,unicodedata,sys,pkgutil

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import dlprotect
from resources.lib.modules import nombredeliens
from collections import defaultdict
from itertools import *

print 'from'


class source:
    def __init__(self):
        print 'INIT'
        self.domains = ['http://www.zone-telechargement.com/']
        self.base_link = 'http://www.zone-telechargement.com/'
        self.search_link = 'http://www.zone-telechargement.com/index.php?q=%s'
        self.titleFR = None
        self.titleCA = None


    def movie(self, imdb, title, year):
        print 'MOVIE'
        try:
            title = 'http://www.imdb.com/title/%s' % imdb

            request = client.request(title, headers={'Accept-Language':'fr-FR'})
            self.titleFR = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleFR = re.sub('(?:\(|\s)\d{4}.+', '', self.titleFR).strip()
            print 'titleFR 0 = %s' % self.titleFR

            request = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()
            print 'titleCA 0 = %s' % self.titleCA

            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)

            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        print 'TVSHOW'
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)

            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        print 'EPISODE'
        try:
            if url == None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)

            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        print 'SOURCES'

        try:
            sources = []
            queryList = []
            cleaned_result = []
            listeHostUrl = []
            theMetaDataVoix = None
            theMetaDataQualite = None
            lookFor = None
            theChunkDetailTaille = None
            theChunkDetailUrl = None

            titleFRsplit = None
            titleCAsplit = None

            if url == None: return sources

            hostDict2 = ['1fichier.com','alterupload.com','cjoint.net','desfichiers.com','dfichiers.com','megadl.fr','mesfichiers.org','piecejointe.net','pjointe.com','tenvoi.com','dl4free.com','24uploading.com','2shared.com','4shared.com',
    'alfafile.net','allmyvideos.net','anafile.com','catshare.net','cbs.com','clicknupload.me','clicknupload.com','clicknupload.link','cloudtime.to','divxstage.eu','divxstage.to','dailymotion.com','datafile.com','datafilehost.com',
    'datei.to','depfile.com','i-filez.com','dl.free.fr','easybytez.com','exashare.com','bojem3a.info','ajihezo.info','extmatrix.com','faststore.org','filefactory.com','fileflyer.com','fileover.net','filerio.com','filerio.in',
    'filesabc.com','filesflash.com','filesflash.net','filesmonster.com','gigapeta.com','gigasize.com','gboxes.com','gulfup.com','hugefiles.net','hulkshare.com','keep2share.cc','k2s.cc','keep2s.cc','k2share.cc','kingfiles.net','letitbit.net',
    'load.to','mediafire.com','mega.co.nz','mega.nz','megashares.com','mightyupload.com','movshare.net','wholecloud.net','nitroflare.com','novamov.com','auroravid.to','nowdownload.eu','nowdownload.ch','nowdownload.sx','nowdownload.ag',
    'nowdownload.at','nowdownload.ec','nowdownload.li','nowdownload.to','nowvideo.eu','nowvideo.ch','nowvideo.sx','nowvideo.ag','nowvideo.at','nowvideo.li','oboom.com','openload.co','openload.io','ozofiles.com','promptfile.com','purevid.com',
    'sky.fm','radiotunes.com','rapidgator.net','rg.to','rarefile.net','redbunker.net','redtube.com','canalplus.fr','rockfile.eu','rutube.ru','salefiles.com','scribd.com','secureupload.eu','sendspace.com','share-online.biz','shareflare.net',
    'solidfiles.com','soundcloud.com','speedyshare.com','streamin.to','thevideo.me','turbobit.net','tusfiles.net','ulozto.net','uloz.to','ulozto.sk','unibytes.com','uplea.com','upload.af','uploadable.ch','bigfile.to','uploadc.com',
    'uploadc.ch','uploaded.net','uploaded.to','ul.to','uploading.com','uploadrocket.net','uploadx.org','upstore.net','uptobox.com','uptostream.com','userporn.com','userscloud.com','veevr.com','videoweed.es','bitvid.sx','vimeo.com',
    'vip-file.com','wipfiles.net','worldbytez.com','youporn.com','youtube.com','youwatch.org','chouhaa.info','yunfile.com','filemarkets.com','5xpan.com','dix3.com','zippyshare.com']


            #if debrid.status() == False: raise Exception()

            dt = int(datetime.datetime.now().strftime('%Y%m%d'))
            mt = {'jan':'1', 'feb':'2', 'mar':'3', 'apr':'4', 'may':'5', 'jun':'6', 'jul':'7', 'aug':'8', 'sep':'9', 'oct':'10', 'nov':'11', 'dec':'12'}

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = 'http://www.imdb.com/title/%s' % data['imdb']
            print 'title = %s' % title

            request = client.request(title, headers={'Accept-Language':'fr-FR'})
            self.titleFR = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleFR = re.sub('(?:\(|\s)\d{4}.+', '', self.titleFR).strip()
            print 'titleFR 0 = %s' % self.titleFR

            request = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()
            print 'titleCA 0 = %s' % self.titleCA


            if 'tvshowtitle' in data :
                print ''
            else:
                try:
                    dataYearFR = re.compile('Release Date:</h4> (.+?) \(France\)').findall(request)[0]
                    dataYearFR = dataYearFR[-4:]
                except:
                    try:
                        dataYearFR = re.compile('Release Date:</h4> (.+?) \(USA\)').findall(request)[0]
                        dataYearFR = dataYearFR[-4:]
                    except:
                        dataYearFR = re.compile('<title>(.+?) \- IMDb</title>').findall(request)[0]
                        dataYearFR = re.compile('\((.+?)\)').findall(dataYearFR)[0]
                        
                        
                        
            print self.titleFR, self.titleCA
                        

            if self.titleFR[-1:] == '.':
                self.titleFR = self.titleFR[:-1]

            try:
                self.titleFR = re.sub('\&amp\;', '', self.titleFR).strip()
            except:
                pass

            result = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result)[0].strip()
            #self.titleCA = client.parseDOM(result,'title')[0]
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()

            if self.titleCA[-1:] == '.':
                self.titleCA = self.titleCA[:-1]

            try:
                self.titleCA = re.sub('\&amp\;', '', self.titleCA).strip()
            except:
                pass

            if 'tvshowtitle' in data :
                self.titleCA = re.sub('\(TV Series', '', self.titleCA).strip()
                self.titleFR = re.sub('\(TV Series', '', self.titleFR).strip()

            try:
                if ' - ' in self.titleFR or ' - ' in self.titleCA:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
                    queryList.append(titleFRsplit[0] + ' ' + titleCAsplit[1])
                    queryList.append(titleCAsplit[0] + ' ' + titleFRsplit[1])

                else:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
            except:
                pass

            queryList = sorted(set(queryList))

            for i in queryList:

                query = i

                lookFor2 = i

                try:
                    if 'tvshowtitle' in data :
                        lookFor = re.sub('(\s\(TV Series|\s\(TV Mini-Series)', '', query).strip()

                    query = re.sub('(:| - )', '', query)

                    lookFor = query

                except:
                    pass

                if 'tvshowtitle' in data :
                    typeMovies = 'tvshows'
                    typeQuery = 'field'
                else:
                    typeMovies = 'movies'
                    typeQuery = 'q'

                if 'tvshowtitle' in data :
                    lookFor = re.sub(' ', '+', lookFor)
                    lookFor = lookFor + '+' + data['season']
                else:
                    query = self.search_link % (query)

                lookFor = re.sub('\\\'', ' ', lookFor)

                if 'tvshowtitle' in data :
                    #http://www.zone-telechargement.com/telecharger-series.html?q=person+of+interest+3&minrating=0&tab=all&orderby_by=date&orderby_order=desc&tv=all
                    url = 'http://www.zone-telechargement.com/telecharger-series.html'
                    post = 'q=%s&orderby_by=popular' % (lookFor).strip()
                    result = client.request(url, post=post)

                    if result == None:
                        continue

                    theUrlList = re.compile('<a title=\"\" href=\"http://www.zone-telechargement.com/(.+?)\"').findall(result)
                    theUrlList = list(filter(lambda x: '.html' not in x , theUrlList))

                    for ttt in theUrlList:

                        tempSaison = '- Saison %d' %  (int(data['season']))
                        #'Person Of Interest - Saison 3 [Complete] VF [HD 1080p]'

                        result2 = client.request('http://www.zone-telechargement.com/' + ttt)

                        theTitle = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result2)[0].strip()

                        if tempSaison in theTitle:
                            print ''
                        else:
                            continue

                        theTitle = re.sub('(Télécharger|Gratuitement|gratuitement|French)', '', theTitle)
                        theTitle = re.sub('(’|\')', ' ', theTitle)
                        theTitle = re.sub(':', '', theTitle).lower()
                        theTitle = re.sub('  ', ' ', theTitle).lower()

                        #theTitle = theTitle.encode('utf-8')

                        if lookFor2.lower() in theTitle:
                            print ''
                        else:
                            continue

                        if 'tvshowtitle' in data :
                            theMetaDataVoix = 'NA'
                            theMetaDataQualite = 'NA'

                            try:
                                theUrlListEpisodes = re.compile('<b>Saison :(.+?)Publié le <time>', re.MULTILINE | re.DOTALL).findall(result2)[0]

                                try:
                                    theUrlListEpisodes2 = re.compile('<a href=\"http://www.dl-protect.com/(.+?)\" target=\"_blank\">Episode', re.MULTILINE | re.DOTALL).findall(theUrlListEpisodes)

                                    if theUrlListEpisodes2 == []:
                                        continue
                                except:
                                    continue
                            except:
                                continue

                            aChunk = re.compile('<b>Langue : </b>(.+?)<div align=\"center\"><img src=\"http://www.zone-telechargement.com/prez/style/v1/liens.png\"', re.MULTILINE | re.DOTALL).findall(result2)[0]

                            try:
                                theMetaDataVoix = re.compile('<b>Langue : </b>(.+?)<br', re.MULTILINE | re.DOTALL).findall(theUrlListEpisodes)[0]

                                theMetaDataVoix = re.sub('Français', 'VF', theMetaDataVoix)
                            except:
                                theMetaDataVoix = 'NA'

                            try:
                                theMetaDataQualite = re.compile('<b>Qualité : </b>(.+?)<br', re.MULTILINE | re.DOTALL).findall(theUrlListEpisodes)[0]
                            except:
                                theMetaDataQualite = 'NA'

                            tempurl = re.sub('<br />', '</br>', theUrlListEpisodes)

                            aHost = re.compile('<span style=\"color:#[0-9a-fA-F]{6}\"(.+?)</a></br></br>', re.MULTILINE | re.DOTALL).findall(tempurl)

                            for www in aHost:
                                unHost = re.compile('>(.+?)</span><', re.MULTILINE | re.DOTALL).findall(www)

                                tempHost = ''
                                theHost3 = ''

                                for unHost2 in hostDict2:
                                    theHostPos = unHost2.rfind('.')
                                    theHost3 = unHost2[:theHostPos]

                                    if theHost3 in unHost[0].lower() and theHost3 not in 'load':

                                        try:
                                            rrr = re.compile('http://www.dl-protect.com/(.+?)\" target=\"_blank\">Episode %d' % int(data['episode']), re.MULTILINE | re.DOTALL).findall(www)[0]
                                        except:
                                            continue

                                        nombredeliens.var1 = nombredeliens.var1 + 1

                                        url = 'http://www.dl-protect.com/' + rrr
                                        url = url.encode('utf-8')
                                        #url = dlprotect.decrypt(tempurl)

                                        host = unHost2
                                        host = host.encode('utf-8')

                                        language = theMetaDataVoix

                                        quality2nd = theMetaDataQualite

                                        size = '%.2f GB' % (0)

                                        if '0.00 GB' in size:
                                            size = ''
                                        else:
                                            size = size + ' | '

                                        RDbool = False

                                        prefaudio = 4
                                        prefaudio = int(control.setting('pref.audio'))

                                        if prefaudio == 0 and language == 'VF':
                                            sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                        elif prefaudio == 1 and language == 'VFQ':
                                            sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                        elif prefaudio == 2 and language == 'VO':
                                            sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                        elif prefaudio == 3 and language == 'VOSTFR':
                                            sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                        elif prefaudio == 4 :
                                            sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})

                else:
                    url = 'http://www.zone-telechargement.com/films-gratuit.html'
                    post = 'q=%s&orderby_by=popular' % (lookFor).strip()
                    result = client.request(url, post=post)

                    if result == None:
                        continue

                    theUrlList = re.compile('<a title=\"\" href=\"http://www.zone-telechargement.com/(.+?)\"').findall(result)
                    theUrlList = list(filter(lambda x: '.html' not in x , theUrlList))

                    for ttt in theUrlList:

                        result2 = client.request('http://www.zone-telechargement.com/' + ttt)

                        theTitle = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result2)[0].strip()
                        theTitle = re.sub('(Télécharger|Gratuitement|gratuitement|French)', '', theTitle)
                        theTitle = re.sub('(’|\')', ' ', theTitle)
                        theTitle = re.sub(':', '', theTitle).lower()
                        theTitle = re.sub('  ', ' ', theTitle).lower()

                        lookFor = lookFor.lower().strip()

                        if lookFor in theTitle:
                            print ''
                        else:
                            continue

                        theMetaData = re.compile('<meta name=\"description\"(.+?)Origine du film', re.MULTILINE | re.DOTALL).findall(result2)[0].strip()
                        theMetaData = re.sub('content="', '', theMetaData)
                        theMetaData = self.cleanFrench(theMetaData)
                        theyear = re.compile('e de production : </b>(.+?)<br', re.MULTILINE | re.DOTALL).findall(result2)[0].strip()

                        try:
                            theMetaDataSplit = theMetaData.split('|')

                            if '(' in  theMetaDataSplit[0].strip() and  ')' in theMetaDataSplit[0].strip():
                                theMetaDataVoix = re.compile('^(.+?)Qualite', re.MULTILINE | re.DOTALL).findall(theMetaDataSplit[0].strip())[0]
                                theMetaDataQualite = re.compile('Qualite(.+?)$', re.MULTILINE | re.DOTALL).findall(theMetaDataSplit[1].strip())[0]
                            else:
                                theMetaDataVoix = re.compile('^(.+?)Qualite', re.MULTILINE | re.DOTALL).findall(theMetaDataSplit[1].strip())[0]
                                theMetaDataQualite = re.compile('Qualite(.+?)$', re.MULTILINE | re.DOTALL).findall(theMetaDataSplit[1].strip())[0]

                            theMetaDataVoix = re.sub(' = vraie voix francaise', '', theMetaDataVoix.lower())
                        except:
                            theMetaDataVoix = 'NA'
                            theMetaDataQualite = 'NA'

                        theChunk = re.compile('<b>Format :(.+?)Publié le <time>', re.MULTILINE | re.DOTALL).findall(result2)[0].strip()

                        theChunkDetail = re.compile('<span style=\"color:#[0-9a-fA-F]{6}\"(.+?)</a><br /><br />', re.MULTILINE | re.DOTALL).findall(theChunk)

                        for theChunkDetaillisteHost in theChunkDetail:

                            theChunkDetailLinks = re.compile('>(.+?)target=\"_blank\">T', re.MULTILINE | re.DOTALL).findall(theChunkDetaillisteHost)

                            for yyy in theChunkDetailLinks:

                                if 'Partie ' in yyy or not 'http://www.dl-protect.com' in yyy or 'Traduit par' in yyy or 'des sous-titres' in yyy or 'Premium' in yyy:
                                    continue
                                else:

                                    tempHost = ''

                                    for hhh in hostDict2:
                                        theHostPos = hhh.rfind('.')
                                        theHost = hhh[:theHostPos]

                                        if theHost in yyy.lower() and theHost not in 'load':
                                            theChunkDetailHost = theHost
                                            theChunkDetailUrl = re.compile('<a href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(yyy)[0]
                                            nombredeliens.var1 = nombredeliens.var1 + 1

                                            if 'tvshowtitle' in data :
                                                print''
                                            else:
                                                if theyear in dataYearFR:
                                                    print''
                                                else:
                                                    continue

                                            url = theChunkDetailUrl
                                            url = url.encode('utf-8')
                                            #url = dlprotect.decrypt(tempurl)

                                            host = theChunkDetailHost
                                            host = host.encode('utf-8')

                                            language = theMetaDataVoix

                                            quality2nd = theMetaDataQualite

                                            size = '%.2f GB' % (0)

                                            if '0.00 GB' in size:
                                                size = ''
                                            else:
                                                size = size + ' | '

                                            RDbool = False

                                            prefaudio = 4
                                            prefaudio = int(control.setting('pref.audio'))

                                            if prefaudio == 0 and language == 'VF':
                                                sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                            elif prefaudio == 1 and language == 'VFQ':
                                                sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                            elif prefaudio == 2 and language == 'VO':
                                                sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                            elif prefaudio == 3 and language == 'VOSTFR':
                                                sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                                            elif prefaudio == 4 :
                                                sources.append({'source': host, 'quality': 'SD', 'provider': 'Zonetelechargement', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})

            return sources

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print  exc_type, exc_tb.tb_lineno

            return sources


    def resolve(self, url):
        print 'RESOLVE'

        url = url.encode('utf-8')

        if 'dl-protect' in url:
            url = dlprotect.decrypt(url)

        return url


    def cleanFrench(self, aString):
        print 'CLEANFRENCH'

        aString = re.sub('(À|Ä|Â)', 'A', aString)
        aString = re.sub('(Ç)', 'C', aString)
        aString = re.sub('(È|É|Ê|Ë)', 'E', aString)
        aString = re.sub('(Ï|Î)', 'I', aString)
        aString = re.sub('(Ö|Ô)', 'O', aString)
        aString = re.sub('(Ü|Û|Ù)', 'U', aString)

        aString = re.sub('(à|ä|â)', 'a', aString)
        aString = re.sub('(ç)', 'c', aString)
        aString = re.sub('(è|é|ê|ë)', 'e', aString)
        aString = re.sub('(ï|î)', 'i', aString)
        aString = re.sub('(ö|ô)', 'o', aString)
        aString = re.sub('(ü|û|ù)', 'u', aString)

        return aString