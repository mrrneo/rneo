# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urlparse,time,datetime,unicodedata,sys,pkgutil

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import nombredeliens

class source:
    def __init__(self):
        print '= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = '
        print 'INIT'
        self.domains = ['http://www.voirfilms.org']
        self.base_link = 'http://www.voirfilms.org/rechercher'
        self.search_link = '%s'



    def movie(self, imdb, title, year):
        print 'MOVIE'
        try:
            title = 'http://www.imdb.com/title/%s' % imdb

            titleFR = client.request(title, headers={'Accept-Language':'fr-FR'})
            titleFR = client.parseDOM(titleFR,'title')[0]
            titleFR = re.sub('(?:\(|\s)\d{4}.+', '', titleFR).strip()
            #titleFR = ''.join((c for c in unicodedata.normalize('NFD', titleFR) if unicodedata.category(c) != 'Mn'))

            titleCA = client.request(title, headers={'Accept-Language':'fr-CA'})
            titleCA = client.parseDOM(titleCA,'title')[0]
            titleCA = re.sub('(?:\(|\s)\d{4}.+', '', titleCA).strip()
            #titleCA = ''.join((c for c in unicodedata.normalize('NFD', titleCA) if unicodedata.category(c) != 'Mn'))

            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        print 'TVSHOW'
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        print 'EPISODE'
        try:
            if url == None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        print 'SOURCES'
        try:
            sources = []
            queryList = []
            cleaned_result = []
            cleaned_result7 = []

            titleFRsplit = None
            titleCAsplit = None

            if url == None: return sources

            dt = int(datetime.datetime.now().strftime('%Y%m%d'))
            mt = {'jan': '1', 'feb': '2', 'mar': '3', 'apr': '4', 'may': '5', 'jun': '6', 'jul': '7', 'aug': '8',
                  'sep': '9', 'oct': '10', 'nov': '11', 'dec': '12'}

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = 'http://www.imdb.com/title/%s' % data['imdb']
            print 'title = %s' % title

            request = client.request(title, headers={'Accept-Language':'fr-FR'})
            self.titleFR = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleFR = re.sub('(?:\(|\s)\d{4}.+', '', self.titleFR).strip()
            print 'titleFR 0 = %s' % self.titleFR

            request = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()
            print 'titleCA 0 = %s' % self.titleCA


            if 'tvshowtitle' in data :
                print ''
            else:
                try:
                    dataYearFR = re.compile('Release Date:</h4> (.+?) \(France\)').findall(request)[0]
                    dataYearFR = dataYearFR[-4:]
                except:
                    try:
                        dataYearFR = re.compile('Release Date:</h4> (.+?) \(USA\)').findall(request)[0]
                        dataYearFR = dataYearFR[-4:]
                    except:
                        dataYearFR = re.compile('<title>(.+?) \- IMDb</title>').findall(request)[0]
                        dataYearFR = re.compile('\((.+?)\)').findall(dataYearFR)[0]

            if self.titleFR[-1:] == '.':
                self.titleFR = self.titleFR[:-1]

            try:
                self.titleFR = re.sub('\&amp\;', '', self.titleFR).strip()
            except:
                pass

            result = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result)[0].strip()
            #self.titleCA = client.parseDOM(result,'title')[0]
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()

            if self.titleCA[-1:] == '.':
                self.titleCA = self.titleCA[:-1]

            try:
                self.titleCA = re.sub('\&amp\;', '', self.titleCA).strip()
            except:
                pass

            if 'tvshowtitle' in data :
                self.titleCA = re.sub('\(TV Series', '', self.titleCA).strip()
                self.titleFR = re.sub('\(TV Series', '', self.titleFR).strip()

            try:
                if ' - ' in self.titleFR or ' - ' in self.titleCA:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
                    queryList.append(titleFRsplit[0] + ' ' + titleCAsplit[1])
                    queryList.append(titleCAsplit[0] + ' ' + titleFRsplit[1])

                else:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
            except:
                pass

            queryList = sorted(set(queryList))

            quality2nd = 'SD'
            language = 'VF'

            try:
                for i in queryList:

                    query = i

                    try:
                        query = re.sub('(:)', ' :', query)

                        if ':' in query and '-' in query:
                            test = re.split('(:| - )', query)
                            test2 = [x for x in test if x != ':']
                            test2 = [x for x in test2 if x != ' - ']

                            lookFor1 = test2[1]
                            lookFor = test2[2]

                        elif ':' in query:
                            test = re.split('(:)', query)
                            test2 = [x for x in test if x != ':']

                            lookFor1 = test2[0]
                            lookFor = test2[1]
                        else:
                            lookFor = query

                        if 'tvshowtitle' in data:
                            lookFor = re.sub('(\s\(TV Series)', '', lookFor).strip()
                            lookFor = re.sub('(\.)', '', lookFor).strip()

                    except:
                        pass

                    if 'tvshowtitle' in data:
                        typeMovies = 'tvshows'
                        typeQuery = 'field'
                    else:
                        typeMovies = 'movies'
                        typeQuery = 'q'

                    if 'tvshowtitle' in data:
                        lookFor = re.sub('(\s)', '%20', lookFor)
                        query = self.search_link % (lookFor)
                        lookFor = query
                    else:
                        query = self.search_link % (query)

                    url = 'http://www.voirfilms.org/rechercher'

                    if 'tvshowtitle' in data:

                        for se in queryList:

                            se = re.sub('(\s\(tv series)', '', se).strip()
                            post = ('action=recherche&story='+se)
                            url = url.encode('utf-8')
                            post = re.sub(' ', '+', post)
                            post = post.encode('utf-8')

                            resultUrl2a = client.request(url, post=post)

                            try:
                                cleaned_result = re.compile('<div class=\"imagefilm\">\s*<a href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl2a)
                            except:
                                pass

                            for m in cleaned_result:

                                resultUrl3 = client.request(m)

                                try:
                                    cleaned_result2 = re.compile('<div class=\"unepetitesaisons\">\s*<a href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl3)
                                except:
                                    pass

                                for hhh in cleaned_result2:

                                    if '-saison-%s-' % data['season'] in hhh:
                                        print ''
                                    else:
                                        continue

                                    resultUrl5 = client.request(hhh)
                                    cleaned_result5 = re.compile(', \" href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl5)

                                    for ee in cleaned_result5:
                                        if '-episode-%s-' % data['episode'] in ee:
                                            tempEpisode = ee
                                        else:
                                            continue

                                        resultUrl2d = client.request('http://www.voirfilms.org/'+ tempEpisode)
                                        print 'http://www.voirfilms.org/'+ tempEpisode

                                        cleaned_result1 = re.compile('<li class=\"seme\"(.+?)target=\"filmPlayer\"', re.MULTILINE | re.DOTALL).findall(resultUrl2d)
                                        cleaned_resultlang = re.compile('width:55px;\" class="(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl2d)

                                        for ii in cleaned_result1:
                                            cleaned_result2 = re.compile('<a href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(ii)[0]
                                            cleaned_result7.append(cleaned_result2)

                                    quality = 'SD'

                        cleaned_result = cleaned_result7

                    else:
                        lookFor = re.sub('(\s\(TV Series)', '', lookFor).strip()
                        lookFor = re.sub(' ', '+', lookFor)
                        post = 'action=recherche&story=%s' % (lookFor).strip()
                        post = post.encode('utf-8')
                        resultUrl2f = client.request(url, post=post)

                        try:
                            cleaned_result = re.compile('<div class=\"imagefilm\">\s*<a href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl2f)[0]
                        except:
                            pass

                        if cleaned_result == [] :
                            continue

                        resultUrl2g = client.request(cleaned_result)

                        theTitle = re.compile('<title>film (.+?) streaming vf</title>', re.MULTILINE | re.DOTALL).findall(resultUrl2g)[0].lower()

                        if theTitle in self.titleFR.lower():
                            print''
                        else:
                           continue

                        theyear = re.compile('<a href=\"/films/annee\-(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl2g)[0]

                        cleaned_result = re.compile('<li class=\"seme\"(.+?)target=\"filmPlayer\"', re.MULTILINE | re.DOTALL).findall(resultUrl2g)
                        cleaned_resultlang = re.compile('width:55px;\" class="(.+?)\"', re.MULTILINE | re.DOTALL).findall(resultUrl2g)
                        quality2nd = re.compile('http://www.voirfilms.org/filmqualite/(.+?)/', re.MULTILINE | re.DOTALL).findall(resultUrl2g)[0]

                        quality = 'SD'

                    index = 0

                    for i in cleaned_result:

                        if 'tvshowtitle' in data :
                            print''
                        else:
                            if theyear in dataYearFR:
                                print''
                            else:
                               continue

                        size = '%.2f GB' % (0)

                        if '0.00 GB' in size:
                            size = ''
                        else:
                            sizel = size + ' | '

                        RDbool = False

                        if 'tvshowtitle' in data:
                            url = i
                        else:
                            url = re.compile('<a href=\"(.+?)\"', re.MULTILINE | re.DOTALL).findall(i)[0]

                        url = url.encode('utf-8')

                        nombredeliens.var1 = nombredeliens.var1 + 1

                        host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                        host = host.encode('utf-8')
                        url = url.encode('utf-8')

                        language = cleaned_resultlang[index].upper()
                        language = re.sub('L', '', language)

                        index += 1

                        prefaudio = 4
                        prefaudio = int(control.setting('pref.audio'))

                        if prefaudio == 0 and language == 'VF':
                              sources.append({'source': host, 'quality': quality, 'provider': 'Voirfilms', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                        elif prefaudio == 1 and language == 'VFQ':
                              sources.append({'source': host, 'quality': quality, 'provider': 'Voirfilms', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                        elif prefaudio == 2 and language == 'VO':
                              sources.append({'source': host, 'quality': quality, 'provider': 'Voirfilms', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                        elif prefaudio == 3 and language == 'VOSTFR':
                              sources.append({'source': host, 'quality': quality, 'provider': 'Voirfilms', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                        elif prefaudio == 4 :
                              sources.append({'source': host, 'quality': quality, 'provider': 'Voirfilms', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                print  exc_type, exc_tb.tb_lineno

            return sources
        except:
            return sources

    def resolve(self, url):
        print 'RESOLVE'
        return url
