# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urlparse,time,datetime,unicodedata,sys,pkgutil

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import nombredeliens

class source:

    def __init__(self):
        print '= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = '
        print 'INIT'
        self.domains = ['http://sokrostream.biz']
        self.base_link = 'http://sokrostream.biz'
        self.search_link = ''

    def movie(self, imdb, title, year):
        print 'MOVIE'
        try:
            title = 'http://www.imdb.com/title/%s' % imdb

            titleFR = client.request(title, headers={'Accept-Language':'fr-FR'})
            titleFR = client.parseDOM(titleFR,'title')[0]
            titleFR = re.sub('(?:\(|\s)\d{4}.+', '', titleFR).strip()
            #titleFR = ''.join((c for c in unicodedata.normalize('NFD', titleFR) if unicodedata.category(c) != 'Mn'))

            titleCA = client.request(title, headers={'Accept-Language':'fr-CA'})
            titleCA = client.parseDOM(titleCA,'title')[0]
            #dataYearCA = re.compile('\((.+?)\)').findall(titleCA)[0]
            titleCA = re.sub('(?:\(|\s)\d{4}.+', '', titleCA).strip()
            #titleCA = ''.join((c for c in unicodedata.normalize('NFD', titleCA) if unicodedata.category(c) != 'Mn'))
            #print 'titleCA 0 = %s' % titleCA

            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        print 'TVSHOW'
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        print 'EPISODE'
        try:
            if url == None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        print 'SOURCES'
        try:
            sources = []
            queryList = []
            cleaned_result = []

            titleFRsplit = None
            titleCAsplit = None

            if url == None: return sources

            dt = int(datetime.datetime.now().strftime('%Y%m%d'))
            mt = {'jan':'1', 'feb':'2', 'mar':'3', 'apr':'4', 'may':'5', 'jun':'6', 'jul':'7', 'aug':'8', 'sep':'9', 'oct':'10', 'nov':'11', 'dec':'12'}

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = 'http://www.imdb.com/title/%s' % data['imdb']
            print 'title = %s' % title

            request = client.request(title, headers={'Accept-Language':'fr-FR'})
            self.titleFR = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleFR = re.sub('(?:\(|\s)\d{4}.+', '', self.titleFR).strip()
            print 'titleFR 0 = %s' % self.titleFR

            request = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(request)[0].strip()
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()
            print 'titleCA 0 = %s' % self.titleCA


            if 'tvshowtitle' in data :
                print ''
            else:
                try:
                    dataYearFR = re.compile('Release Date:</h4> (.+?) \(France\)').findall(request)[0]
                    dataYearFR = dataYearFR[-4:]
                except:
                    try:
                        dataYearFR = re.compile('Release Date:</h4> (.+?) \(USA\)').findall(request)[0]
                        dataYearFR = dataYearFR[-4:]
                    except:
                        dataYearFR = re.compile('<title>(.+?) \- IMDb</title>').findall(request)[0]
                        dataYearFR = re.compile('\((.+?)\)').findall(dataYearFR)[0]

            if self.titleFR[-1:] == '.':
                self.titleFR = self.titleFR[:-1]

            try:
                self.titleFR = re.sub('\&amp\;', '', self.titleFR).strip()
            except:
                pass

            result = client.request(title, headers={'Accept-Language':'fr-CA'})
            self.titleCA = re.compile('<title>(.+?)</title>', re.MULTILINE | re.DOTALL).findall(result)[0].strip()
            #self.titleCA = client.parseDOM(result,'title')[0]
            self.titleCA = re.sub('(?:\(|\s)\d{4}.+', '', self.titleCA).strip()

            if self.titleCA[-1:] == '.':
                self.titleCA = self.titleCA[:-1]

            try:
                self.titleCA = re.sub('\&amp\;', '', self.titleCA).strip()
            except:
                pass

            if 'tvshowtitle' in data :
                self.titleCA = re.sub('\(TV Series', '', self.titleCA).strip()
                self.titleFR = re.sub('\(TV Series', '', self.titleFR).strip()

            try:
                if ' - ' in self.titleFR or ' - ' in self.titleCA:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
                    queryList.append(titleFRsplit[0] + ' ' + titleCAsplit[1])
                    queryList.append(titleCAsplit[0] + ' ' + titleFRsplit[1])

                else:
                    queryList.append(self.titleFR)
                    queryList.append(self.titleCA)
            except:
                pass


            try:
                queryList = sorted(set(queryList))

                for i in queryList:

                    query = i

                    try:
                        query2 = urllib.quote_plus(query)
                    except:
                        query2 = re.sub(' ', '+', query)

                    if 'tvshowtitle' in data :
                        tempSearch = 'http://sokrostream.biz/search.php?slug=&slug=%s' % (query2)
                    else:
                        tempSearch = 'http://sokrostream.biz/search.php?slug=&slug=%s' % (query2)
                        tempSearch = re.sub(' ', '+', tempSearch)

                    tempSearch = tempSearch.encode('utf-8')

                    try:
                        result = client.request(tempSearch)
                    except:
                        pass

                    cleaned_result = []

                    try:
                        if result == None:
                            pass
                        else:
                            if 'tvshowtitle' in data :
                                cleaned_result = re.compile('<div class=\"movief\"><a href=\"(.+?)\">').findall(result)
                            else:
                                cleaned_result = re.compile('<div class=\"movief\"><a href=\"(.+?)\">').findall(result)

                    except:
                        pass

                    if cleaned_result == [] :
                        continue

                    cleaned_result = sorted(set(cleaned_result))

                    for resultUrl in cleaned_result:

                        if 'tvshowtitle' in data :
                            if not '/series/' in resultUrl:
                                continue

                        resultUrl2 = client.request(resultUrl)

                        if 'tvshowtitle' in data :  

                            resultUrl10a = re.compile('div class=\"moviefilm\">\s*<a href="http://sokrostream.biz/series-tv/(.+?)\">').findall(resultUrl2)

                            for m in resultUrl10a:
                                tempEpisode4 = '-saison-%s' % data['season']

                                if int(data['season']) < 10:
                                    tempEpisode4b = '-saison-0%s' % data['season']

                                if not ((tempEpisode4 in m) or (tempEpisode4b in m)):
                                    continue

                                resultUrl2b = client.request('http://sokrostream.biz/series-tv/' + m)
                                resultUrl10b = re.compile('<div class=\"movief2\"><a href=\"(.+?)\"').findall(resultUrl2b)

                                for q in resultUrl10b:

                                    tempEpisode4c = '-episode-%s' % data['episode']

                                    if int(data['episode']) < 10:
                                        tempEpisode4d = '-episode-0%s' % data['episode']
                                    else:
                                        tempEpisode4d = '-episode-%s' % data['episode']

                                    if not ((tempEpisode4c in q) or (tempEpisode4d in q)):
                                        continue
                                    else:
                                        resultUrl2c = client.request(q)
                                        resultUrl11 = re.compile('<input name=\"levideo\" value=\"(.+?)\" type="hidden">').findall(resultUrl2c)

                                        result4 = []

                                        for k in resultUrl11:
                                            url = q
                                            post = 'levideo=%s' % k
                                            resultUrl2a = client.request(url, post=post)
                                            resultUrl3 = re.compile('<iframe width=[0-9]{3,4} height=[0-9]{3,4} src=(.+?) ').findall(resultUrl2a)

                                            if resultUrl3 == []:
                                                continue

                                            result4.append(resultUrl3[0])
                                    break

                                break

                        else:

                            resultUrl11 = re.compile('<input name=\"levideo\" value=\"(.+?)\" type="hidden">').findall(resultUrl2)

                            result4 = []

                            for k in resultUrl11:
                                post = 'levideo=%s' % k
                                resultUrl2a = client.request(resultUrl, post=post)
                                resultUrl3 = re.compile('<iframe width=[0-9]{3,4} height=[0-9]{3,4} src=(.+?) ').findall(resultUrl2a)

                                theyear = re.compile('<p><span>Années</span>:\s(.+?)</a>').findall(resultUrl2a)[0]
                                theyear = re.compile('rel=\"tag\">(.+?)$').findall(theyear)[0]

                                if resultUrl3 == []:
                                    continue

                                result4.append(resultUrl3[0])

                        try:
                            qualite0 = re.compile('<p><span>Qualit(.+?)/a>').findall(resultUrl2a)[0]
                            qualite1 = re.compile('rel=\"tag\">(.+?)<').findall(qualite0)[0]
                        except:
                            qualite1 = 'SD'

                        language =  'VF'

                        quality = 'SD'

                        for i in result4:

                            if 'tvshowtitle' in data :
                                print''
                            else:
                                if theyear in dataYearFR:
                                    print''
                                else:
                                    continue

                            size = '%.2f GB' % (0)

                            if '0.00 GB' in size:
                                size = ''
                            else:
                                sizel = size + ' | '

                            RDbool = False

                            url = i

                            if 'http://sokrostream.biz/' in url:
                                result = client.request(url)
                                url = re.compile('href=\"http://uptobox.com/(.+?)\"').findall(result)[0]
                                url = 'http://uptobox.com/' + url

                            url = url.encode('utf-8')

                            nombredeliens.var1 = nombredeliens.var1 + 1

                            quality2nd = qualite1

                            host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]

                            host = host.encode('utf-8')
                            url = url.encode('utf-8')

                            prefaudio = 4
                            prefaudio = int(control.setting('pref.audio'))

                            if prefaudio == 0 and language == 'VF':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Sokrostream', 'info': size + quality2nd + '| ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 1 and language == 'VFQ':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Sokrostream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 2 and language == 'VO':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Sokrostreamm', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 3 and language == 'VOSTFR':
                                sources.append({'source': host, 'quality': quality, 'provider': 'Sokrostream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})
                            elif prefaudio == 4 :
                                sources.append({'source': host, 'quality': quality, 'provider': 'Sokrostream', 'info': size + quality2nd + ' | ' + language, 'url': url, 'direct': False, 'debridonly': RDbool})

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                print  exc_type, exc_tb.tb_lineno

            return sources
        except:
            return sources


    def resolve(self, url):
        print 'RESOLVE'
        return url