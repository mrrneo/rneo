var1 = 0
theTraktFavorisMovies = []
theTraktFavorisTVShows = []
theTVShowsCalendarIndex = []
theTVShowsCalendar = []
theTVShowsCalendarUser = []
downloadPercentage = 10