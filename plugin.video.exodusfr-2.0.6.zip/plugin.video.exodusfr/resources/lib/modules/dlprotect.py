#-*- coding: utf-8 -*-

from time import time

from socket import timeout

import re,os,urllib2,urllib,base64

import xbmc,xbmcgui,xbmcaddon


def decrypt(url):

    if not 'dl-protect.com' in str(url): return url

    headers = {
    'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0',
    'Referer' : url ,
    'Host' : 'www.dl-protect.com',
    'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-gb, en;q=0.9',
    'Content-Type' : 'application/x-www-form-urlencoded',
    }

    request = urllib2.Request(url,None,headers)

    try: 
        reponse = urllib2.urlopen(request,timeout = 5)
    except urllib2.URLError, e:
        return
    except urllib2.HTTPError, e:
        return
    except timeout:
        return

    UrlRedirect = reponse.geturl()

    if not(UrlRedirect == url):
        reponse.close()
        return UrlRedirect
        
    result = reponse.read()

    if 'A technical problem occurred' in result:
        return

    if 'the link you are looking for is not found' in result:
        return

    cookies=reponse.info()['Set-Cookie']

    c2 = re.findall('(?:^|,) *([^;,]+?)=([^;,\/]+?);',cookies)

    if not c2:
        return
    cookies = ''

    for cook in c2:
        cookies = cookies + cook[0] + '=' + cook[1]+ ';'

    reponse.close()


    if 'Please enter the characters from the picture to see the links' in result:
        s = re.findall('<img id="captcha" alt="Security code" src="([^<>"]+?)"',result)

        if 'http://www.dl-protect.com' in s[0]:
            image = s[0]
        else:
            image = 'http://www.dl-protect.com' + s[0]

        captcha = get_response(image,cookies)

        key = re.findall('name="key" value="(.+?)"',result)

        mstime = int(round(time() * 1000))
        b64time = "_" + base64.urlsafe_b64encode(str(mstime)).replace("=", "%3D")

        #query_args = ( ('key' , key[0] ) , ( 'i' , b64time) , ('secure' , captcha ), ('submitform','') , ( 'submitform' , 'Decrypt link')  )
        query_args = (('key', key[0]), ('i', b64time), ('secureio', captcha ), ('secure', ''), ('submitform', ''), ('submitform', 'Decrypt+link'), ('check_mode', 'ok'))
        
        data = urllib.urlencode(query_args)

        headers.update({'Cookie': cookies})

        request = urllib2.Request(url,data,headers)

        try: 
            reponse = urllib2.urlopen(request)
        except urllib2.URLError, e:
            pass

        strm = reponse.read()
        
        strm = re.findall('id\s*=\s*(?:\"|\')slinks(?:\"|\').+?href\s*=\s*(?:\"|\')(.+?)(?:\"|\')', strm)
        if strm: return strm[0]
    
        reponse.close()

        if 'Please enter the characters from the picture to see the links' in result:
            return


    elif 'Please click on continue to see' in result:

        key = re.findall('input name="key" value="(.+?)"',result)

        mstime = int(round(time() * 1000))
        b64time = "_" + base64.urlsafe_b64encode(str(mstime)).replace("=", "%3D")

        xbmc.sleep(1000)
        
        query_args = ( ('submitform' , '' ) , ( 'key' , key[0] ) , ('i' , b64time ), ( 'submitformio' , 'Continue'), ('check_mode', 'ok') )
        data = urllib.urlencode(query_args)

        headers.update({'Cookie': cookies})

        request = urllib2.Request(url,data,headers)

        try: 
            reponse = urllib2.urlopen(request)
        except urllib2.URLError, e:
            pass

        strm = reponse.read()

        reponse.close()


    strm = re.findall('id\s*=\s*(?:\"|\')slinks(?:\"|\').+?href\s*=\s*(?:\"|\')(.+?)(?:\"|\')', strm)

    if strm: return strm[0]

    return
 

def get_response(img,cookie):

    path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

    filename  = os.path.join(path,'img')

    headers2 = {
        'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0',
        'Host' : 'www.dl-protect.com',
        'Accept' : 'image/png,image/*;q=0.8,*/*;q=0.5',
        'Accept-Language': 'en-gb, en;q=0.9',
        'Accept-Encoding' : 'gzip, deflate',
        'Content-Type' : 'application/x-www-form-urlencoded',
        'Cookie' : cookie
        }
        
    try:
        req = urllib2.Request(img,None,headers2)
        web = urllib2.urlopen(req)

        if web.headers.maintype == 'image':
            buf = web.read()
            download = file(filename, 'wb')
            download.write(buf)
            download.close()
            web.close()
        else:
            return
    except:
        return


    solution = ''
    try:
        img = xbmcgui.ControlImage(450, 0, 400, 130, filename)
        wdlg = xbmcgui.WindowDialog()
        wdlg.addControl(img)
        wdlg.show()

        #xbmc.sleep(3000)

        kb = xbmc.Keyboard('', 'Type the letters in the image', False)
        kb.doModal()

        if (kb.isConfirmed()):
            solution = kb.getText()
    finally:
        wdlg.removeControl(img)
        wdlg.close()

    return solution